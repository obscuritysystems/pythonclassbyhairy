import types
import unittest

class TestGenExp(unittest.TestCase):
    def test_genexp(self):
        # Generator Expressions
        #
        # Create a generator expression ``to_five`` that generates
        # the numbers from 1 up to and including 5
        # ================================
        
        self.assert_(isinstance(to_five, types.GeneratorType))
        self.assertEquals(to_five.next(), 1)
        self.assertEquals(list(to_five), [2,3,4,5])

        # Generator Expressions
        #
        # Write a function ``not_none`` that accepts a sequence
        # and uses a generator expression to generate the items
        # that aren't None
        # ================================
        
        self.assert_(isinstance(not_none(range(3)), types.GeneratorType))
        self.assertEquals(not_none([None, 1]).next(), 1)
        self.assertRaises(StopIteration, not_none([None]).next)



if __name__ == '__main__':
    unittest.main()
