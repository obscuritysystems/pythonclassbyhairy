import unittest

class TestFunctions(unittest.TestCase):
    def test_function(self):
        # Variable args
        #
        # Create a function ``backwards`` that accepts multiple
        # arguments and returns the arguments backwards
        # ================================
        
        # note that when passing a sequence, we need to flatten with the ``*``
        self.assertEquals(backwards(*[0,1,2]), [2,1,0])
        # no flattening required here
        self.assertEquals(backwards(3,2,1), [1,2,3])


        # Invoking variable args
        #
        # Create a function ``shove_args`` that takes one normal
        # parameter, ``func``, one named parameter and variable args.
        # It should call ``func`` and pass in the named parameter and
        # variable args as variable args.
        # ================================
        
        self.assertEquals(shove_args(backwards, 1, *[0, 2]), [2,0,1])


        # Keyword args
        #
        # Create a function ``sorted_keys`` that accepts only keyword
        # arguments and returns the sorted keys of those arguments
        # ================================
        
        a_dict = {'a':1, 'b':2}
        # note that we have to pass in a dict with **
        self.assertEquals(sorted_keys(**a_dict), ['a', 'b'])
        self.assertEquals(sorted_keys(c=3, d=5),['c', 'd'])

if __name__ == '__main__':
    unittest.main()
