import types
import unittest

class TestGenerators(unittest.TestCase):

    def test_gen(self):
        # Generators
        #
        # Implement a generator ``two`` that yields 1 then 2
        # ================================

        two_gen = two()
        self.assert_(isinstance(two_gen, types.GeneratorType))
        self.assertEquals(next(two_gen), 1)
        self.assertEquals(next(two_gen), 2)
        self.assertRaises(StopIteration, next, two_gen)

        # Generator
        #
        # Implement a generator ``countdown`` that takes a integer yields the sequence from range(integer, -1, -1)
        # ================================
        
        one = countdown(1)
        self.assert_(isinstance(one, types.GeneratorType))
        self.assertEquals(next(one), 1)
        self.assertEquals(next(one), 0)
        self.assertRaises(StopIteration, next, one)

if __name__ == '__main__':
    unittest.main()
