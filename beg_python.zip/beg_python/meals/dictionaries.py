import unittest

class TestDicts(unittest.TestCase):
    def test_dicts(self):
        """
        A basic introduction to dictionaries
        """
        # Create the variable ``ssn2name`` and assign to an empty dict
        #**************************************************

        self.assertEquals(ssn2name, {})

        # map the string '123-456' to 'Fred'
        #**************************************************

        self.assertEquals(ssn2name['123-456'], 'Fred')

        # map the string '765-432' to 'George'
        #**************************************************

        self.assertEquals(ssn2name['765-432'], 'George')


        # use ``in`` to see if '765-432' is there.
        # assign the results to variable ``d``

        self.assertEquals(d, True)

        # use ``del`` to remove '765-432'

        self.assert_('765-432' not in ssn2name)

if __name__ == '__main__':
    unittest.main()
