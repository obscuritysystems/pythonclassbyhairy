import types
import unittest

class SampleTest(unittest.TestCase):
    def test_example(self):
        """
        An example of how to do the tests
        """
        # Variables
        #
        # Create a variable ``name`` that is assigned to the string
        # "Matt".
        # ================================
        
        self.assert_(isinstance(name, types.StringType))
        self.assertEquals(name, 'Matt')

if __name__ == '__main__':
    unittest.main()
